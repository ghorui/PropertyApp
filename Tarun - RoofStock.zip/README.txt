DB Scripts contains following commands:
  1. Create Database
  2. Create Tables
  3. Create Stored Proc.

Service - Designed with Core and ADO.NET
Angular UI - do a npm install. and run "ng serve --open"


Database server information needs to be updated in "\SamplePropertiesApp\SamplePropertiesApp\appsettings.json"